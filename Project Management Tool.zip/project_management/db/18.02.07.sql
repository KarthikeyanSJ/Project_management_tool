UPDATE `config` SET `attribute` = 'session_lifetime' WHERE `attribute` = 'JAR.expire';
UPDATE `config` SET `value` = '18.02.07' WHERE `attribute` = 'version';

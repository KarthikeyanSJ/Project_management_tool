UPDATE `config` SET `attribute` = 'session_lifetime' WHERE `attribute` = 'JAR.lifetime';
UPDATE `config` SET `value` = '18.02.19' WHERE `attribute` = 'version';

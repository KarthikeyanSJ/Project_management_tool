<?php
return array (
  'db.host' => 'localhost',
  'db.port' => '3306',
  'db.user' => 'root',
  'db.pass' => '',
  'db.name' => 'project_management',
);

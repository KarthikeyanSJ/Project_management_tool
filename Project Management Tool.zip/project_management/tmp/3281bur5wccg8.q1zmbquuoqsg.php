<?php $types = array();
    foreach($issue_types as $type) {
        if($type['id'] > 0 && $type['id'] < 10) {
            array_push($types, $type['id']);
        }
    } ?>
<script>var BASE = '<?= ($BASE) ?>', issue_types = <?= (json_encode($types)) ?>;</script>
<script src="<?= ($BASE) ?>/minify/js/jquery-3.2.1.min.js,bootstrap.min.js,modernizr.custom.js,mousetrap-1.6.2.min.js"></script>
<script src="<?= ($BASE) ?>/js/global.js"></script>
<script src="<?= ($BASE) ?>/js/respond.min.js"></script>

<?php foreach ((\Helper\Plugin::instance()->getJsFiles($PATH)?:[]) as $file): ?>
    <script src="<?= ($file) ?>"></script>
<?php endforeach; ?>
<?php foreach ((\Helper\Plugin::instance()->getJsCode($PATH)?:[]) as $code): ?>
    <?= ($code)."
" ?>
<?php endforeach; ?>

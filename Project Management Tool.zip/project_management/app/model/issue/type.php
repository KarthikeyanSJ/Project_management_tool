<?php

namespace Model\Issue;

/**
 * Class Type
 *
 * @property int $id
 * @property string $name
 */
class Type extends \Model
{
    protected $_table_name = "issue_type";
}

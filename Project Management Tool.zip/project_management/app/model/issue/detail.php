<?php

namespace Model\Issue;

class Detail extends \Model\Issue
{
    protected $_table_name = "issue_detail";
    public $children = [];
}

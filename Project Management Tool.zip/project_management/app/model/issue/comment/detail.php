<?php

namespace Model\Issue\Comment;

class Detail extends \Model\Issue\Comment
{
    protected $_table_name = "issue_comment_detail";
}

<?php

namespace Model\Issue\Comment;

class User extends \Model\Issue\Comment
{
    protected $_table_name = "issue_comment_user";
}

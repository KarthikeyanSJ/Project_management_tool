<?php

namespace Model\Issue\File;

class Detail extends \Model\Issue\File
{
    protected $_table_name = "issue_file_detail";
}
